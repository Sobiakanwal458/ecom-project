﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace SK
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetMethod();
            }
        }
        public void GetMethod()
        {
            SqlConnection conn = null;
            SqlDataReader rdr = null;

            SqlCommand com = null;
            using (conn = new SqlConnection("Data Source=AMMAR-PC;Initial Catalog=SKCreations;Integrated Security=True"))
            {
                conn.Open();

                // 1.  create a command object identifying the stored procedure
                SqlCommand cmd = new SqlCommand("GetImages", conn);

                // 2. set the command object so it knows to execute a stored procedure
                cmd.CommandType = CommandType.StoredProcedure;

                // 3. add parameter to command, which will be passed to the stored procedure
                //cmd.Parameters.Add(new SqlParameter("@CustomerID", custId));

                // execute the command
                using ( rdr = cmd.ExecuteReader())
                {
                    // iterate through results, printing each to console
                    while (rdr.Read())
                    {
                    //    //Code here
                        myImg.ImageUrl = rdr["Image1"].ToString(); ;
                        myImage2.ImageUrl = rdr["Image2"].ToString(); ;
                        myImage3.ImageUrl = rdr["Image3"].ToString(); ;
                        myImage1.ImageUrl = rdr["Image4"].ToString();
                    }
                }
            }

            
        }
    }
}